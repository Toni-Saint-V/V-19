import { CursorGlow } from "./components/effects/cursor-glow";
import { NoiseOverlay } from "./components/effects/noise-overlay";
import { BentoFeatures } from "./components/sections/bento-features";
import { FinalCTA } from "./components/sections/final-cta";
import { HeroNoirAurora } from "./components/sections/hero-noir-aurora";
import { LogoMarquee } from "./components/sections/logo-marquee";
import { PremiumNav } from "./components/sections/premium-nav";
import { PricingCards } from "./components/sections/pricing-cards";

export default function App() {
  return (
    <main className="na-app-shell">
      <CursorGlow />
      <NoiseOverlay />
      <PremiumNav />
      <HeroNoirAurora />
      <LogoMarquee />
      <BentoFeatures />
      <PricingCards />
      <FinalCTA />
    </main>
  );
}
