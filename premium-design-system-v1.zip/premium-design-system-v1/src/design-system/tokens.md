# Tokens — Noir Aurora V1

## Color tokens

| Token | Value | Purpose |
|---|---:|---|
| `--na-bg` | `#05060a` | main background |
| `--na-bg-2` | `#080a10` | secondary background |
| `--na-bg-3` | `#0d1018` | elevated dark |
| `--na-text` | `#f7f3ea` | primary warm white |
| `--na-text-soft` | `rgba(247,243,234,.78)` | secondary text |
| `--na-text-muted` | `rgba(247,243,234,.58)` | muted body |
| `--na-cyan` | `#74f7ff` | primary accent |
| `--na-violet` | `#9b7cff` | secondary accent |
| `--na-fuchsia` | `#ff6fd8` | rare highlight |
| `--na-gold` | `#f6d992` | luxury highlight, use rarely |

## Surface tokens

| Token | Purpose |
|---|---|
| `--na-surface` | default glass surface |
| `--na-surface-strong` | stronger panel |
| `--na-surface-hover` | hover surface |
| `--na-border` | hairline border |
| `--na-border-strong` | active/featured border |

## Radius tokens

| Token | Value |
|---|---:|
| `--na-radius-xs` | `10px` |
| `--na-radius-sm` | `14px` |
| `--na-radius-md` | `20px` |
| `--na-radius-lg` | `28px` |
| `--na-radius-xl` | `36px` |
| `--na-radius-pill` | `999px` |

## Motion tokens

| Token | Value | Purpose |
|---|---:|---|
| `--na-duration-fast` | `150ms` | small hover states |
| `--na-duration-base` | `280ms` | default interactions |
| `--na-duration-slow` | `720ms` | reveal / cinematic transitions |
| `--na-duration-ambient` | `12s` | background movement |
| `--na-ease-out` | `cubic-bezier(0.16,1,0.3,1)` | clean UI easing |
| `--na-ease-luxury` | `cubic-bezier(0.19,1,0.22,1)` | premium reveal |

## Typography rules

```txt
Hero: huge, tight, editorial.
Lead: calm, readable, muted.
Captions: uppercase, restrained tracking.
Buttons: semibold, compact, precise.
```
