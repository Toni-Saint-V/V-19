# Component Map — Noir Aurora V1

## Primitives

### `Button`

Variants:

```ts
"primary" | "secondary" | "ghost" | "danger"
```

Sizes:

```ts
"sm" | "md" | "lg"
```

Use:

```tsx
<Button variant="primary" size="lg">Start</Button>
```

### `Badge`

Small premium label.

```tsx
<Badge>Premium system</Badge>
```

### `GlassCard`

Default premium surface.

```tsx
<GlassCard interactive>...</GlassCard>
```

### `SectionHeading`

Standard section title block.

```tsx
<SectionHeading
  eyebrow="System"
  title="One visual language"
  lead="Reusable, consistent and strict."
/>
```

---

## Motion

### `Reveal`

Scroll reveal wrapper.

```tsx
<Reveal delay={0.1}>...</Reveal>
```

### `SplitText`

Hero-grade text reveal.

```tsx
<SplitText text="Premium interfaces without chaos." />
```

### `MagneticButton`

Use only for primary CTA.

```tsx
<MagneticButton variant="primary" size="lg">Start</MagneticButton>
```

---

## Effects

### `AuroraBackground`

Ambient hero/page glow.

### `NoiseOverlay`

Fixed subtle texture. Use once in app shell.

### `CursorGlow`

Premium pointer feedback. Use once in app shell; disable if product is performance-sensitive.

### `GradientOrb`

Local glow object for CTA/cards.

---

## Sections

### `PremiumNav`

Fixed glass navigation.

### `HeroNoirAurora`

Main premium hero.

### `BentoFeatures`

Feature system block.

### `LogoMarquee`

Social proof strip.

### `PricingCards`

Commercial packaging block.

### `FinalCTA`

Closing conversion section.

---

## Recommended page order

```tsx
<PremiumNav />
<HeroNoirAurora />
<LogoMarquee />
<BentoFeatures />
<PricingCards />
<FinalCTA />
```

## Next components to add

1. `TestimonialsWall`
2. `ProductShowcase`
3. `DashboardPreview`
4. `ShaderHeroObject`
5. `FAQAccordion`
6. `FeatureComparison`
7. `FooterPremium`
8. `PageTransition`
9. `ScrollParallaxShowcase`
10. `CommandMenu`
