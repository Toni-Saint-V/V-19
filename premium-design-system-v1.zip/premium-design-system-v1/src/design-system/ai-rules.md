# AI Rules — How to generate inside Noir Aurora

Используй этот файл как system/developer prompt для Figma Make, v0, Cursor, Claude Code или другого AI-кодера.

## Основное правило

AI не должен создавать новую дизайн-систему. Он должен использовать существующие компоненты и токены Noir Aurora.

## Prompt template

```txt
Собери React/TypeScript section/page в стиле Noir Aurora.

Стиль:
- dark editorial luxury
- near-black background
- warm white typography
- cyan/violet accent only in key areas
- glass cards with hairline borders
- subtle noise and aurora glow
- premium calm, not gaming/neon overload

Композиция:
- strict grid
- strong visual anchor
- large type
- generous negative space
- max 1 primary CTA per section

Motion:
- use Reveal for scroll appearance
- use SplitText only for hero headline or key section title
- use MagneticButton only for main CTA
- keep animations slow, soft and consistent
- support prefers-reduced-motion

Implementation:
- use existing components from src/components
- use CSS variables from src/styles/globals.css
- do not invent new color palette
- do not add random gradients
- do not add unnecessary dependencies
- output clean, reusable components
```

## Anti-patterns

AI часто портит premium стиль так:

```txt
- слишком много glow;
- rainbow gradient everywhere;
- cards без сетки;
- разные радиусы в каждом блоке;
- слишком быстрые анимации;
- заголовки с обычным line-height 1.2 вместо editorial 0.82–0.96;
- mobile без отдельной композиции;
- новые кнопки вместо Button/MagneticButton;
- новый CSS вместо токенов.
```

## Хорошая команда AI

```txt
Сделай новый блок testimonials, используя Noir Aurora:
- SectionHeading
- GlassCard
- Reveal
- Badge
- Button только если нужен CTA
- grid responsive
- не добавляй новые цвета
- все значения брать из CSS variables
```

## Code review checklist для AI-кода

1. Использует ли код существующие компоненты?
2. Не появились ли новые random hex цвета?
3. Не добавлены ли лишние dependencies?
4. Есть ли responsive состояние?
5. Есть ли reduced motion где нужна сложная анимация?
6. Анимации имеют один стиль и easing?
7. Главный CTA визуально главный?
8. Можно ли переиспользовать блок без переписывания?
