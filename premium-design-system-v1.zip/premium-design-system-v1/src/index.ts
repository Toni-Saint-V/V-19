export { Button } from "./components/primitives/button";
export type { ButtonProps, ButtonSize, ButtonVariant } from "./components/primitives/button";
export { Badge } from "./components/primitives/badge";
export type { BadgeProps } from "./components/primitives/badge";
export { GlassCard } from "./components/primitives/glass-card";
export type { GlassCardProps } from "./components/primitives/glass-card";
export { Container } from "./components/primitives/container";
export { SectionHeading } from "./components/primitives/section-heading";
export type { SectionHeadingProps } from "./components/primitives/section-heading";

export { Reveal } from "./components/motion/reveal";
export type { RevealProps } from "./components/motion/reveal";
export { SplitText } from "./components/motion/split-text";
export type { SplitTextProps } from "./components/motion/split-text";
export { MagneticButton } from "./components/motion/magnetic-button";
export type { MagneticButtonProps } from "./components/motion/magnetic-button";

export { AuroraBackground } from "./components/effects/aurora-background";
export { CursorGlow } from "./components/effects/cursor-glow";
export { GradientOrb } from "./components/effects/gradient-orb";
export type { GradientOrbProps } from "./components/effects/gradient-orb";
export { NoiseOverlay } from "./components/effects/noise-overlay";

export { PremiumNav } from "./components/sections/premium-nav";
export type { NavLink, PremiumNavProps } from "./components/sections/premium-nav";
export { HeroNoirAurora } from "./components/sections/hero-noir-aurora";
export type { HeroNoirAuroraProps } from "./components/sections/hero-noir-aurora";
export { BentoFeatures } from "./components/sections/bento-features";
export type { BentoFeature } from "./components/sections/bento-features";
export { LogoMarquee } from "./components/sections/logo-marquee";
export type { LogoMarqueeProps } from "./components/sections/logo-marquee";
export { PricingCards } from "./components/sections/pricing-cards";
export { FinalCTA } from "./components/sections/final-cta";

export { useMousePosition } from "./hooks/use-mouse-position";
export type { MousePosition } from "./hooks/use-mouse-position";
export { usePrefersReducedMotion } from "./hooks/use-prefers-reduced-motion";
