import type { HTMLAttributes } from "react";
import { cn } from "../../lib/cn";

export function NoiseOverlay({ className, ...props }: HTMLAttributes<HTMLDivElement>) {
  return <div className={cn("na-noise-overlay", className)} aria-hidden="true" {...props} />;
}
