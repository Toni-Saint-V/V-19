import type { CSSProperties, HTMLAttributes } from "react";
import { useMousePosition } from "../../hooks/use-mouse-position";
import { cn } from "../../lib/cn";

export function CursorGlow({ className, style, ...props }: HTMLAttributes<HTMLDivElement>) {
  const { x, y } = useMousePosition();
  const cssVars = {
    "--mouse-x": `${x}px`,
    "--mouse-y": `${y}px`,
    ...style
  } as CSSProperties;

  return <div className={cn("na-cursor-glow", className)} style={cssVars} aria-hidden="true" {...props} />;
}
