import type { HTMLAttributes } from "react";
import { cn } from "../../lib/cn";

export function AuroraBackground({ className, ...props }: HTMLAttributes<HTMLDivElement>) {
  return (
    <div className={cn("na-aurora", className)} aria-hidden="true" {...props}>
      <span className="na-aurora__orb na-aurora__orb--one" />
      <span className="na-aurora__orb na-aurora__orb--two" />
      <span className="na-aurora__orb na-aurora__orb--three" />
    </div>
  );
}
