import type { CSSProperties, HTMLAttributes } from "react";
import { cn } from "../../lib/cn";

export type GradientOrbProps = HTMLAttributes<HTMLDivElement> & {
  size?: number;
  color?: string;
  blur?: number;
  opacity?: number;
};

export function GradientOrb({
  className,
  style,
  size = 280,
  color = "rgba(116,247,255,0.42)",
  blur = 28,
  opacity = 0.55,
  ...props
}: GradientOrbProps) {
  const cssVars = {
    "--orb-size": `${size}px`,
    "--orb-color": color,
    "--orb-blur": `${blur}px`,
    "--orb-opacity": opacity,
    ...style
  } as CSSProperties;

  return <div className={cn("na-gradient-orb", className)} style={cssVars} aria-hidden="true" {...props} />;
}
