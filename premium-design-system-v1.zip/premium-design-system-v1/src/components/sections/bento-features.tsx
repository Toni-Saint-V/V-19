import type { ComponentType } from "react";
import { Cpu, Gauge, Layers3, LockKeyhole, Orbit, WandSparkles } from "lucide-react";
import { SectionHeading } from "../primitives/section-heading";
import { Reveal } from "../motion/reveal";

export type BentoFeature = {
  title: string;
  text: string;
  icon: ComponentType<{ size?: number }>;
  size: "wide" | "medium" | "third";
};

const features: BentoFeature[] = [
  {
    title: "Design tokens before decoration",
    text: "Color, radius, surface, type, shadow and motion live in one language. New screens inherit the same taste instead of inventing a new style.",
    icon: Layers3,
    size: "wide"
  },
  {
    title: "Motion with hierarchy",
    text: "Reveal, stagger, hover and ambient motion are controlled by rules. No chaotic animation soup.",
    icon: Orbit,
    size: "medium"
  },
  {
    title: "AI-ready components",
    text: "Prompt tools can assemble pages from stable primitives instead of generating throwaway code.",
    icon: WandSparkles,
    size: "third"
  },
  {
    title: "Production surfaces",
    text: "Glass cards, hairline borders, glow accents and restrained depth tuned for premium dark UI.",
    icon: Cpu,
    size: "third"
  },
  {
    title: "Fast iteration",
    text: "Use Figma Make, v0 or Cursor as composition assistants. The source of truth remains your component system.",
    icon: Gauge,
    size: "third"
  },
  {
    title: "Accessible foundation",
    text: "Reduced motion support, semantic sections, visible focus states and predictable contrast are included from V1.",
    icon: LockKeyhole,
    size: "wide"
  }
];

export function BentoFeatures() {
  return (
    <section className="na-section" id="system">
      <div className="na-container">
        <Reveal>
          <SectionHeading
            eyebrow="System architecture"
            title={<>A premium look only works when the rules are stricter than the effects.</>}
            lead="This V1 gives you a visual grammar: reusable primitives, controlled animation, reliable spacing and sections that can be rearranged without visual collapse."
          />
        </Reveal>

        <div className="na-bento-grid">
          {features.map((feature, index) => {
            const Icon = feature.icon;

            return (
              <Reveal
                delay={0.06 * index}
                key={feature.title}
                className={`na-glass-card na-glass-card--interactive na-bento-card na-bento-card--${feature.size}`}
              >
                <div className="na-bento-card__icon" aria-hidden="true">
                  <Icon size={20} />
                </div>
                <h3>{feature.title}</h3>
                <p>{feature.text}</p>
                <span className="na-bento-card__visual" aria-hidden="true" />
              </Reveal>
            );
          })}
        </div>
      </div>
    </section>
  );
}
