export type LogoMarqueeProps = {
  items?: string[];
};

const defaultItems = ["Aurora", "Vertex", "Northstar", "Obsidian", "Signal", "Prism", "Forge", "Lumen"];

export function LogoMarquee({ items = defaultItems }: LogoMarqueeProps) {
  const track = [...items, ...items];

  return (
    <section className="na-logo-marquee" aria-label="Trusted by">
      <div className="na-logo-track">
        {track.map((item, index) => (
          <div className="na-logo-item" key={`${item}-${index}`}>
            {item}
          </div>
        ))}
      </div>
    </section>
  );
}
