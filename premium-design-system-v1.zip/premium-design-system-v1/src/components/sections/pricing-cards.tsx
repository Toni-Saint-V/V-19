import { Check, Crown } from "lucide-react";
import { Button } from "../primitives/button";
import { Badge } from "../primitives/badge";
import { Reveal } from "../motion/reveal";
import { SectionHeading } from "../primitives/section-heading";

const tiers = [
  {
    name: "Core",
    description: "For a single product landing or MVP interface.",
    price: "€249",
    period: "starter",
    featured: false,
    features: ["Core tokens", "Hero + bento + CTA", "Motion primitives", "Vite demo app"]
  },
  {
    name: "Studio",
    description: "For multiple projects with a stable premium visual language.",
    price: "€799",
    period: "system",
    featured: true,
    features: ["Everything in Core", "Pricing + nav + marquee", "AI prompt rules", "Registry-ready structure", "Component map"]
  },
  {
    name: "Custom",
    description: "For dashboards, crypto apps, AI tools or brand-specific systems.",
    price: "€2k+",
    period: "bespoke",
    featured: false,
    features: ["Custom visual direction", "Dashboard components", "Advanced motion", "Brand tokens", "Implementation support"]
  }
];

export function PricingCards() {
  return (
    <section className="na-section" id="pricing">
      <div className="na-container">
        <Reveal>
          <SectionHeading
            align="center"
            eyebrow="Commercial layer"
            title={<>Package the system like a premium product, not like loose components.</>}
            lead="Use these pricing cards as structure: replace the numbers, keep the hierarchy. Premium pricing UI needs clarity first, glow second."
          />
        </Reveal>

        <div className="na-pricing-grid">
          {tiers.map((tier, index) => (
            <Reveal
              delay={0.08 * index}
              key={tier.name}
              className={`na-glass-card na-pricing-card ${tier.featured ? "na-pricing-card--featured" : ""}`}
            >
              <div className="na-pricing-card__top">
                <div>
                  <h3>{tier.name}</h3>
                  <p>{tier.description}</p>
                </div>
                {tier.featured ? (
                  <Badge dot={false}>
                    <Crown size={14} /> Best
                  </Badge>
                ) : null}
              </div>

              <div className="na-price">
                <strong>{tier.price}</strong>
                <span>{tier.period}</span>
              </div>

              <ul className="na-feature-list">
                {tier.features.map((feature) => (
                  <li key={feature}>
                    <Check size={17} />
                    <span>{feature}</span>
                  </li>
                ))}
              </ul>

              <div className="na-pricing-card__action">
                <Button variant={tier.featured ? "primary" : "secondary"} size="lg">
                  Choose {tier.name}
                </Button>
              </div>
            </Reveal>
          ))}
        </div>
      </div>
    </section>
  );
}
