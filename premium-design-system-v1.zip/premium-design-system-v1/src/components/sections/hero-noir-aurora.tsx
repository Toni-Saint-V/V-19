import type { CSSProperties } from "react";
import { ArrowRight, Play, ShieldCheck } from "lucide-react";
import { AuroraBackground } from "../effects/aurora-background";
import { Badge } from "../primitives/badge";
import { Button } from "../primitives/button";
import { GlassCard } from "../primitives/glass-card";
import { MagneticButton } from "../motion/magnetic-button";
import { Reveal } from "../motion/reveal";
import { SplitText } from "../motion/split-text";

export type HeroNoirAuroraProps = {
  eyebrow?: string;
  title?: string;
  lead?: string;
  primaryCta?: string;
  secondaryCta?: string;
};

export function HeroNoirAurora({
  eyebrow = "Premium React design system",
  title = "Interfaces that feel expensive before they explain themselves.",
  lead = "A dark luxury system for React products: cinematic motion, disciplined surfaces, glass depth, precise type and sections that can be assembled fast without losing taste.",
  primaryCta = "Build the system",
  secondaryCta = "View components"
}: HeroNoirAuroraProps) {
  return (
    <section className="na-hero" id="top">
      <AuroraBackground />
      <div className="na-container na-hero__grid">
        <div className="na-hero__copy">
          <Reveal>
            <Badge>{eyebrow}</Badge>
          </Reveal>

          <h1 className="na-hero__title">
            <SplitText text={title} />
          </h1>

          <Reveal delay={0.18}>
            <p className="na-hero__lead">{lead}</p>
          </Reveal>

          <Reveal delay={0.26}>
            <div className="na-hero__actions">
              <MagneticButton variant="primary" size="lg" rightIcon={<ArrowRight size={18} />}>
                {primaryCta}
              </MagneticButton>
              <Button variant="secondary" size="lg" leftIcon={<Play size={18} />}>
                {secondaryCta}
              </Button>
            </div>
          </Reveal>

          <Reveal delay={0.34}>
            <div className="na-hero__meta" aria-label="System metrics">
              <div className="na-stat">
                <p className="na-stat__value">12</p>
                <p className="na-stat__label">core visual and motion tokens</p>
              </div>
              <div className="na-stat">
                <p className="na-stat__value">18+</p>
                <p className="na-stat__label">starter primitives and sections</p>
              </div>
              <div className="na-stat">
                <p className="na-stat__value">0</p>
                <p className="na-stat__label">random styles per generated screen</p>
              </div>
            </div>
          </Reveal>
        </div>

        <Reveal delay={0.2} y={34}>
          <GlassCard className="na-hero-card">
            <div className="na-hero-card__screen">
              <div className="na-hero-card__chrome" aria-hidden="true">
                <span className="na-hero-card__dot" />
                <span className="na-hero-card__dot" />
                <span className="na-hero-card__dot" />
              </div>

              <div className="na-hero-card__content">
                <div className="na-visual-tile na-visual-tile--large" />

                <div className="na-visual-grid">
                  <div className="na-visual-tile na-visual-tile--small">
                    <p className="na-visual-kicker">Motion score</p>
                    <p className="na-visual-value">94</p>
                    <div className="na-visual-bars" aria-hidden="true">
                      <span style={{ "--w": "88%" } as CSSProperties} />
                      <span style={{ "--w": "62%" } as CSSProperties} />
                      <span style={{ "--w": "74%" } as CSSProperties} />
                    </div>
                  </div>

                  <div className="na-visual-tile na-visual-tile--small">
                    <p className="na-visual-kicker">System status</p>
                    <p className="na-visual-value">
                      <ShieldCheck size={32} />
                    </p>
                    <div className="na-visual-bars" aria-hidden="true">
                      <span style={{ "--w": "96%" } as CSSProperties} />
                      <span style={{ "--w": "82%" } as CSSProperties} />
                      <span style={{ "--w": "70%" } as CSSProperties} />
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </GlassCard>
        </Reveal>
      </div>
    </section>
  );
}
