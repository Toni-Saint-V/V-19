import { ArrowRight, Sparkles } from "lucide-react";
import { GradientOrb } from "../effects/gradient-orb";
import { GlassCard } from "../primitives/glass-card";
import { Button } from "../primitives/button";
import { MagneticButton } from "../motion/magnetic-button";
import { Reveal } from "../motion/reveal";

export function FinalCTA() {
  return (
    <section className="na-section" id="cta">
      <div className="na-container">
        <Reveal>
          <GlassCard className="na-final-cta">
            <GradientOrb size={420} opacity={0.42} style={{ right: "-120px", top: "-160px" }} />
            <GradientOrb
              size={320}
              color="rgba(155,124,255,0.38)"
              opacity={0.36}
              style={{ left: "-110px", bottom: "-150px" }}
            />

            <div className="na-eyebrow" style={{ marginInline: "auto", marginBottom: 18 }}>
              Next move
            </div>
            <h2>Stop designing pages. Start composing a signature.</h2>
            <p>
              Keep this as your V1 foundation. Every new project should extend tokens, not break them.
              Every generated block should pass through the same visual rules.
            </p>
            <div className="na-final-cta__actions">
              <MagneticButton variant="primary" size="lg" rightIcon={<ArrowRight size={18} />}>
                Build next screen
              </MagneticButton>
              <Button variant="secondary" size="lg" leftIcon={<Sparkles size={18} />}>
                Save as registry
              </Button>
            </div>
          </GlassCard>
        </Reveal>
      </div>
    </section>
  );
}
