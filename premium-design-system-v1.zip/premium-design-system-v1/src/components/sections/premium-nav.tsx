import { ArrowUpRight, Sparkles } from "lucide-react";
import { Button } from "../primitives/button";

export type NavLink = {
  label: string;
  href: string;
};

export type PremiumNavProps = {
  brand?: string;
  links?: NavLink[];
  ctaLabel?: string;
  ctaHref?: string;
};

const defaultLinks: NavLink[] = [
  { label: "System", href: "#system" },
  { label: "Motion", href: "#motion" },
  { label: "Pricing", href: "#pricing" }
];

export function PremiumNav({
  brand = "Noir Aurora",
  links = defaultLinks,
  ctaLabel = "Start",
  ctaHref = "#cta"
}: PremiumNavProps) {
  return (
    <header className="na-nav-wrap">
      <nav className="na-nav" aria-label="Primary navigation">
        <a className="na-nav__brand" href="#top" aria-label={`${brand} home`}>
          <span className="na-nav__mark" aria-hidden="true">
            <Sparkles size={15} />
          </span>
          <span>{brand}</span>
        </a>

        <div className="na-nav__links" aria-label="Section links">
          {links.map((link) => (
            <a className="na-nav__link" href={link.href} key={link.href}>
              {link.label}
            </a>
          ))}
        </div>

        <div className="na-nav__actions">
          <a href={ctaHref}>
            <Button variant="primary" size="sm" rightIcon={<ArrowUpRight size={15} />}>
              {ctaLabel}
            </Button>
          </a>
        </div>
      </nav>
    </header>
  );
}
