import type { PointerEvent } from "react";
import { motion, useMotionValue, useSpring } from "motion/react";
import { Button, type ButtonProps } from "../primitives/button";
import { usePrefersReducedMotion } from "../../hooks/use-prefers-reduced-motion";

export type MagneticButtonProps = ButtonProps & {
  strength?: number;
};

export function MagneticButton({ strength = 0.22, onPointerMove, onPointerLeave, ...props }: MagneticButtonProps) {
  const reducedMotion = usePrefersReducedMotion();
  const rawX = useMotionValue(0);
  const rawY = useMotionValue(0);
  const x = useSpring(rawX, { stiffness: 180, damping: 18, mass: 0.4 });
  const y = useSpring(rawY, { stiffness: 180, damping: 18, mass: 0.4 });

  const handlePointerMove = (event: PointerEvent<HTMLButtonElement>) => {
    if (!reducedMotion) {
      const rect = event.currentTarget.getBoundingClientRect();
      const offsetX = event.clientX - rect.left - rect.width / 2;
      const offsetY = event.clientY - rect.top - rect.height / 2;
      rawX.set(offsetX * strength);
      rawY.set(offsetY * strength);
    }

    onPointerMove?.(event);
  };

  const handlePointerLeave = (event: PointerEvent<HTMLButtonElement>) => {
    rawX.set(0);
    rawY.set(0);
    onPointerLeave?.(event);
  };

  return (
    <motion.span style={{ x, y, display: "inline-flex" }}>
      <Button onPointerMove={handlePointerMove} onPointerLeave={handlePointerLeave} {...props} />
    </motion.span>
  );
}
