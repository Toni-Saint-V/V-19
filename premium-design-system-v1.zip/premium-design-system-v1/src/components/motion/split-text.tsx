import { motion } from "motion/react";
import { usePrefersReducedMotion } from "../../hooks/use-prefers-reduced-motion";

export type SplitTextProps = {
  text: string;
  className?: string;
  wordClassName?: string;
  delay?: number;
  stagger?: number;
};

export function SplitText({
  text,
  className,
  wordClassName,
  delay = 0,
  stagger = 0.045
}: SplitTextProps) {
  const reducedMotion = usePrefersReducedMotion();
  const words = text.split(" ");

  if (reducedMotion) {
    return <span className={className}>{text}</span>;
  }

  return (
    <span className={className} aria-label={text}>
      {words.map((word, index) => (
        <span className="na-split-word" aria-hidden="true" key={`${word}-${index}`}>
          <motion.span
            className={wordClassName}
            initial={{ y: "110%", opacity: 0 }}
            animate={{ y: "0%", opacity: 1 }}
            transition={{
              duration: 0.78,
              delay: delay + index * stagger,
              ease: [0.19, 1, 0.22, 1]
            }}
          >
            {word}
          </motion.span>
          {index < words.length - 1 ? "\u00a0" : null}
        </span>
      ))}
    </span>
  );
}
