import { motion, type HTMLMotionProps } from "motion/react";
import { usePrefersReducedMotion } from "../../hooks/use-prefers-reduced-motion";
import { cn } from "../../lib/cn";

export type RevealProps = HTMLMotionProps<"div"> & {
  delay?: number;
  y?: number;
  once?: boolean;
};

export function Reveal({
  className,
  delay = 0,
  y = 22,
  once = true,
  children,
  ...props
}: RevealProps) {
  const reducedMotion = usePrefersReducedMotion();

  return (
    <motion.div
      className={cn(className)}
      initial={reducedMotion ? false : { opacity: 0, y }}
      whileInView={reducedMotion ? undefined : { opacity: 1, y: 0 }}
      viewport={{ once, margin: "-80px" }}
      transition={{ duration: 0.72, delay, ease: [0.19, 1, 0.22, 1] }}
      {...props}
    >
      {children}
    </motion.div>
  );
}
