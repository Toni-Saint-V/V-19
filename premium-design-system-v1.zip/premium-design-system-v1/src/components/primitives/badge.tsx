import type { HTMLAttributes } from "react";
import { cn } from "../../lib/cn";

export type BadgeProps = HTMLAttributes<HTMLDivElement> & {
  dot?: boolean;
};

export function Badge({ className, dot = true, children, ...props }: BadgeProps) {
  return (
    <div className={cn("na-badge", className)} {...props}>
      {dot ? <span className="na-badge__dot" aria-hidden="true" /> : null}
      <span>{children}</span>
    </div>
  );
}
