import type { HTMLAttributes, ReactNode } from "react";
import { cn } from "../../lib/cn";

export type SectionHeadingProps = Omit<HTMLAttributes<HTMLDivElement>, "title"> & {
  eyebrow?: ReactNode;
  title: ReactNode;
  lead?: ReactNode;
  align?: "left" | "center";
};

export function SectionHeading({
  className,
  eyebrow,
  title,
  lead,
  align = "left",
  ...props
}: SectionHeadingProps) {
  return (
    <div
      className={cn("na-section-heading", align === "center" && "na-section-heading--center", className)}
      {...props}
    >
      {eyebrow ? <div className="na-eyebrow">{eyebrow}</div> : null}
      <h2 className="na-section-title">{title}</h2>
      {lead ? <p className="na-section-lead">{lead}</p> : null}
    </div>
  );
}
