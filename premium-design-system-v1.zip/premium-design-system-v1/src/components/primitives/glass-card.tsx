import type { HTMLAttributes } from "react";
import { cn } from "../../lib/cn";

export type GlassCardProps = HTMLAttributes<HTMLDivElement> & {
  interactive?: boolean;
};

export function GlassCard({ className, interactive = false, ...props }: GlassCardProps) {
  return (
    <div
      className={cn("na-glass-card", interactive && "na-glass-card--interactive", className)}
      {...props}
    />
  );
}
