# Noir Aurora Premium Design System V1

Премиальная React/TypeScript дизайн‑система для лендингов, SaaS, AI-продуктов, dashboards и промо‑страниц.

Стиль: **тёмный editorial luxury + холодный технологичный акцент + стекло + мягкий glow + строгая сетка + спокойная кинематографичная анимация**.

## Что внутри

```txt
src/
  styles/globals.css                 # токены, reset, utility classes, component CSS
  lib/cn.ts                          # className helper
  hooks/use-prefers-reduced-motion.ts
  hooks/use-mouse-position.ts

  components/primitives/
    button.tsx
    badge.tsx
    glass-card.tsx
    container.tsx
    section-heading.tsx

  components/motion/
    reveal.tsx
    split-text.tsx
    magnetic-button.tsx

  components/effects/
    aurora-background.tsx
    noise-overlay.tsx
    cursor-glow.tsx
    gradient-orb.tsx

  components/sections/
    premium-nav.tsx
    hero-noir-aurora.tsx
    bento-features.tsx
    logo-marquee.tsx
    pricing-cards.tsx
    final-cta.tsx

  design-system/
    style-guide.md
    tokens.md
    ai-rules.md
    component-map.md
```

## Быстрый запуск

```bash
npm install
npm run dev
```

## Как перенести в свой проект

Скопируй в свой React/Next проект:

```txt
src/styles/globals.css
src/lib/cn.ts
src/hooks/*
src/components/*
```

Затем подключи стили один раз:

```tsx
import "./styles/globals.css";
```

В Next.js обычно подключать в `app/layout.tsx` или `pages/_app.tsx`.

## Главный принцип

Не генерируй каждый новый экран “с нуля”. Используй эту систему как **премиальный конструктор**:

```tsx
<PremiumNav />
<HeroNoirAurora />
<BentoFeatures />
<LogoMarquee />
<PricingCards />
<FinalCTA />
```

AI/Figma Make/v0 должны собирать страницы из этих компонентов, а не создавать новую визуальную систему каждый раз.

## Стиль V1: Noir Aurora

- фон: near-black, глубокий графит;
- текст: тёплый белый, приглушённый серый;
- акцент: electric cyan / violet только точечно;
- поверхности: glass panels, hairline borders, blur;
- эффекты: aurora mesh, cursor glow, subtle noise;
- анимация: reveal, stagger, magnetic CTA, мягкие hover states;
- композиция: 12-column ощущение, много воздуха, крупная типографика.

## Рекомендованный стек

- React + TypeScript
- Next.js или Vite
- Motion для UI-анимаций
- Radix/shadcn для сложных доступных компонентов
- Tailwind можно добавить позже, но V1 специально сделана на CSS variables, чтобы не зависеть от конкретной версии Tailwind

## Команды

```bash
npm run dev       # demo
npm run build     # production build
npm run preview   # preview build
```

## Важное

Это V1-скелет. Его задача — дать тебе премиальный визуальный язык и базовую библиотеку. Дальше можно добавить:

- private shadcn registry;
- Storybook;
- токены для light/dark/brand themes;
- dashboard components;
- shader/WebGL hero;
- GSAP/Lenis scroll storytelling.
