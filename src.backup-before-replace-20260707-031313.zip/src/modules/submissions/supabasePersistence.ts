import { getSupabaseClient } from "../../lib/supabase/client";
import type {
  ApplicantInsert,
  ApplicantRow,
  CorrectionInsert,
  ExportBatchRow,
  Json,
  MediaAssetInsert,
  MediaAssetRow,
  QuestionnaireAnswerRow,
  QuestionnaireAnswerInsert,
  StatusHistoryInsert,
  SubmissionDraftPersistencePayload,
  SubmissionRow,
} from "../../lib/supabase/database.types";
import type {
  AppointmentStatus,
  SubmissionStatus as SupabaseSubmissionStatus,
} from "../../types/domain";
import {
  mapSupabasePersistenceError,
  PersistenceObservableError,
} from "../../services/persistenceObservability";
import type { AppProfile } from "../../types/session";
import { familyListTitleFromMainApplicantName } from "./listFormatters";
import { assignSubmissionOwner, ensureSubmissionOwner } from "./ownership";
import { normalizeSubmissionQuestionnaire } from "./questionnaire";
import { isQuestionnaireReviewSource, isQuestionnaireReviewState } from "./types";
import {
  canonicalRequiredMediaReadiness,
  isCanonicalFrontendMediaType,
  normalizeLegacySubmissionStatus,
  toCanonicalStorageMediaType,
} from "./domainContract";
import {
  isPersistablePrivateFileAsset,
  withRecomputedFileCompletion,
} from "./fileAsset";
import { isSubmissionIssueResolved, transitionMatrix } from "./status";
import { normalizeSubmissionForCanonicalRuntime } from "./submissionActions";
import type {
  Applicant,
  Issue,
  QuestionnaireField,
  QuestionnaireReviewSource,
  QuestionnaireReviewState,
  IssueStatus,
  Role,
  Submission,
  ExportPackageIdentity,
  SubmissionFile,
  SubmissionFileType,
  SubmissionHistorySource,
  SubmissionStatus,
} from "./types";

export const cockpitSnapshotVersion = 1;
export const cockpitSnapshotKey = "v19CockpitSnapshot";
export const cockpitSnapshotStorageField =
  "submissions.family_intelligence.v19CockpitSnapshot";
export const cockpitSnapshotStatus = "unreviewed";
const submissionListLimit = 100;
const submissionSelect =
  "id,agent_id,type,title,country,city,travel_date,trip_date_from,trip_date_to,status,priority,readiness_percent,family_intelligence,appointment_status,created_at,submitted_at,review_started_at,accepted_at,exported_at,updated_at" as const;
const applicantSelect =
  "id,submission_id,full_name,questionnaire_percent,media_percent,created_at,updated_at" as const;
const questionnaireAnswerSelect =
  "id,submission_id,applicant_id,section_id,field_id,label,value,updated_by,created_at,updated_at" as const;
const mediaAssetSelect =
  "id,applicant_id,submission_id,type,original_file_name,generated_file_name,storage_bucket,storage_path,mime_type,size_bytes,upload_status,review_status,uploaded_at,reviewed_at,reviewed_by" as const;
const exportBatchSelect =
  "id,created_at,file_name,format,content_fingerprint,idempotency_key,row_count,submission_ids" as const;

export interface CockpitLoadResult {
  ownerIdsBySubmissionId: Map<string, string>;
  submissions: Submission[];
}

type SnapshotEnvelope = {
  submission?: unknown;
  version?: unknown;
};
type CockpitApplicantRow = Pick<
  ApplicantRow,
  "full_name" | "id" | "media_percent" | "questionnaire_percent" | "submission_id"
>;
type CockpitQuestionnaireAnswerRow = Pick<
  QuestionnaireAnswerRow,
  "applicant_id" | "field_id" | "label" | "section_id" | "submission_id" | "value"
>;
type CockpitExportBatchRow = Pick<
  ExportBatchRow,
  | "content_fingerprint"
  | "created_at"
  | "file_name"
  | "format"
  | "id"
  | "idempotency_key"
  | "row_count"
  | "submission_ids"
>;
type CockpitMediaAssetRow = Pick<
  MediaAssetRow,
  | "applicant_id"
  | "generated_file_name"
  | "id"
  | "mime_type"
  | "original_file_name"
  | "review_status"
  | "reviewed_at"
  | "reviewed_by"
  | "size_bytes"
  | "storage_bucket"
  | "storage_path"
  | "submission_id"
  | "type"
  | "upload_status"
  | "uploaded_at"
>;
type QuestionnaireAnswerValueEnvelope = {
  kind: typeof questionnaireAnswerEnvelopeKind;
  reviewConfirmedAtIso?: string;
  reviewConfirmedBy?: string;
  reviewOriginSource?: QuestionnaireReviewSource;
  reviewSource?: QuestionnaireReviewSource;
  reviewState?: QuestionnaireReviewState;
  value: string;
  version: typeof questionnaireAnswerEnvelopeVersion;
};
type QuestionnaireAnswerValueResult = {
  reviewConfirmedAtIso?: string;
  reviewConfirmedBy?: string;
  reviewOriginSource?: QuestionnaireReviewSource;
  reviewSource?: QuestionnaireReviewSource;
  reviewState?: QuestionnaireReviewState;
  value: string;
};

const questionnaireAnswerEnvelopeKind = "v19_questionnaire_field";
const questionnaireAnswerEnvelopeVersion = 1;

function isRecord(value: unknown): value is Record<string, unknown> {
  return Boolean(value) && typeof value === "object" && !Array.isArray(value);
}

export function cockpitSubmissionFingerprint(submission: Submission) {
  return JSON.stringify(submission);
}

export function changedCockpitSubmissions(
  submissions: Submission[],
  baselineFingerprints: ReadonlyMap<string, string>,
) {
  return submissions.filter(
    (submission) =>
      baselineFingerprints.get(submission.id) !==
      cockpitSubmissionFingerprint(submission),
  );
}

export function cockpitSubmissionFingerprintMap(submissions: Submission[]) {
  return new Map(
    submissions.map((submission) => [
      submission.id,
      cockpitSubmissionFingerprint(submission),
    ]),
  );
}

function isCockpitSubmission(value: unknown): value is Submission {
  if (!isRecord(value)) return false;

  return (
    typeof value.id === "string" &&
    typeof value.title === "string" &&
    value.country === "Испания" &&
    Array.isArray(value.applicants) &&
    Array.isArray(value.issues) &&
    Array.isArray(value.files) &&
    Array.isArray(value.history) &&
    isRecord(value.completeness)
  );
}

function snapshotEnvelope(value: Json | null): SnapshotEnvelope | null {
  if (!isRecord(value)) return null;
  const envelope = value[cockpitSnapshotKey];
  return isRecord(envelope) ? envelope : null;
}

export function readCockpitSnapshot(value: Json | null): Submission | null {
  const envelope = snapshotEnvelope(value);
  if (!envelope || envelope.version !== cockpitSnapshotVersion) return null;

  if (!isCockpitSubmission(envelope.submission)) return null;

  try {
    return normalizeSubmissionForCanonicalRuntime(envelope.submission);
  } catch {
    return null;
  }
}

function attachNormalizedApplicantRows(
  submission: Submission,
  applicants: CockpitApplicantRow[],
): Submission {
  if (!applicants.length) return submission;

  const rowsById = new Map(applicants.map((applicant) => [applicant.id, applicant]));

  return {
    ...submission,
    applicants: submission.applicants.map((applicant) => {
      const row = rowsById.get(applicant.id);
      if (!row) return applicant;

      return {
        ...applicant,
        fullName: applicant.fullName || row.full_name,
      };
    }),
  };
}

function attachQuestionnaireAnswerRows(
  submission: Submission,
  answers: CockpitQuestionnaireAnswerRow[],
): Submission {
  if (!answers.length) return submission;

  const answersByApplicantField = new Map(
    answers.map((answer) => [`${answer.applicant_id}:${answer.field_id}`, answer]),
  );

  return normalizeSubmissionQuestionnaire({
    ...submission,
    applicants: submission.applicants.map((applicant) => ({
      ...applicant,
      sections: applicant.sections.map((section) => ({
        ...section,
        fields: section.fields.map((field) => {
          const answer = answersByApplicantField.get(`${applicant.id}:${field.id}`);
          if (!answer) return field;

          const value = questionnaireAnswerFieldValue(answer.value);
          return {
            ...field,
            reviewConfirmedAtIso: value.reviewConfirmedAtIso,
            reviewConfirmedBy: value.reviewConfirmedBy,
            reviewOriginSource: value.reviewOriginSource,
            reviewSource: value.reviewSource,
            reviewState: value.reviewState,
            value: value.value,
          };
        }),
      })),
    })),
  });
}

function fileStatusFromMediaAssetRow(
  row: CockpitMediaAssetRow,
): SubmissionFile["status"] {
  if (row.review_status === "accepted") return "accepted";
  if (
    row.review_status === "replace_required" ||
    row.review_status === "poor_quality"
  ) {
    return "needs_replacement";
  }
  return row.upload_status === "uploaded" ? "uploaded" : "missing";
}

function submissionFileTypeFromMediaAssetRow(
  row: CockpitMediaAssetRow,
): SubmissionFileType | null {
  if (isCanonicalFrontendMediaType(row.type)) {
    return row.type;
  }
  return null;
}

function submissionFileFromMediaAssetRow(
  row: CockpitMediaAssetRow,
): SubmissionFile | null {
  const type = submissionFileTypeFromMediaAssetRow(row);
  if (!type) return null;

  return {
    id: row.id,
    applicantId: row.applicant_id,
    type,
    status: fileStatusFromMediaAssetRow(row),
    generatedFileName: row.generated_file_name ?? undefined,
    mimeType: row.mime_type ?? undefined,
    originalFileName: row.original_file_name ?? undefined,
    reviewedAtIso: row.reviewed_at ?? undefined,
    reviewedBy: row.reviewed_by ?? undefined,
    reviewStatus: row.review_status,
    sizeBytes: row.size_bytes ?? undefined,
    storageAdapter:
      row.upload_status === "uploaded" && row.storage_path
        ? "supabase-private"
        : undefined,
    storageBucket: row.storage_bucket || undefined,
    storagePath: row.storage_path || undefined,
    uploadedAtIso: row.uploaded_at ?? undefined,
    uploadStatus: row.upload_status,
  };
}

function attachDurableMediaAssetRows(
  submission: Submission,
  mediaRows: CockpitMediaAssetRow[],
): Submission {
  if (!mediaRows.length) return withRecomputedFileCompletion(submission);

  const durableFiles = mediaRows
    .map(submissionFileFromMediaAssetRow)
    .filter((file): file is SubmissionFile => Boolean(file));
  if (!durableFiles.length) return withRecomputedFileCompletion(submission);

  const durableFilesByApplicantType = new Map(
    durableFiles.map((file) => [`${file.applicantId}:${file.type}`, file]),
  );
  const overlayedFiles = submission.files.map((file) => {
    const durableFile = durableFilesByApplicantType.get(
      `${file.applicantId}:${file.type}`,
    );
    return durableFile ? { ...file, ...durableFile, id: file.id } : file;
  });
  const existingKeys = new Set(
    overlayedFiles.map((file) => `${file.applicantId}:${file.type}`),
  );
  const missingDurableFiles = durableFiles.filter(
    (file) => !existingKeys.has(`${file.applicantId}:${file.type}`),
  );

  return withRecomputedFileCompletion({
    ...submission,
    files: [...overlayedFiles, ...missingDurableFiles],
  });
}

function exportPackageFromBatchRow(
  row: CockpitExportBatchRow,
): ExportPackageIdentity | undefined {
  if (
    !row.content_fingerprint ||
    !row.file_name ||
    !row.idempotency_key ||
    row.row_count < 1 ||
    row.submission_ids.length < 1
  ) {
    return undefined;
  }

  return {
    contentFingerprint: row.content_fingerprint,
    fileName: row.file_name,
    format: row.format,
    idempotencyKey: row.idempotency_key,
    rowCount: row.row_count,
    submissionIds: [...row.submission_ids].sort(),
  };
}

function latestExportBatchForSubmission(
  submissionId: string,
  rows: CockpitExportBatchRow[],
): CockpitExportBatchRow | undefined {
  return rows
    .filter((row) => row.format === "xlsx" && row.submission_ids.includes(submissionId))
    .sort(
      (left, right) =>
        right.created_at.localeCompare(left.created_at) ||
        right.id.localeCompare(left.id),
    )[0];
}

function exportStateFromDurableRowStatus(
  rowStatus: SubmissionStatus,
): Submission["exportState"] {
  if (rowStatus === "exported") return "marked_exported";
  if (rowStatus === "ready_for_export") return "ready";
  return "not_ready";
}

function clearSnapshotExportPackage(
  submission: Submission,
  rowStatus: SubmissionStatus,
): Submission {
  return {
    ...submission,
    exportPackage: undefined,
    exportState: exportStateFromDurableRowStatus(rowStatus),
  };
}

function attachExportPackageRow(
  submission: Submission,
  rowStatus: SubmissionStatus,
  exportBatches: CockpitExportBatchRow[],
  options: { restoreGeneratedState?: boolean } = {},
): Submission {
  const durableExportState = exportStateFromDurableRowStatus(rowStatus);
  if (durableExportState === "not_ready") {
    return clearSnapshotExportPackage(submission, rowStatus);
  }

  const exportBatch = latestExportBatchForSubmission(submission.id, exportBatches);
  if (!exportBatch) return clearSnapshotExportPackage(submission, rowStatus);

  const exportPackage = exportPackageFromBatchRow(exportBatch);
  if (!exportPackage) return clearSnapshotExportPackage(submission, rowStatus);

  return {
    ...submission,
    exportPackage,
    exportState:
      rowStatus === "exported"
        ? "marked_exported"
        : options.restoreGeneratedState
          ? "file_generated"
          : durableExportState,
  };
}

function reconcileCockpitSnapshotWithSubmissionRow(
  row: Pick<SubmissionRow, "agent_id" | "exported_at" | "status" | "updated_at">,
  snapshot: Submission,
  applicants: CockpitApplicantRow[],
  questionnaireAnswers: CockpitQuestionnaireAnswerRow[],
  exportBatches: CockpitExportBatchRow[],
): Submission {
  const rowStatus = fromSupabaseSubmissionRowStatus(row);
  const normalizedSnapshot = normalizeSubmissionForCanonicalRuntime(
    attachQuestionnaireAnswerRows(
      attachNormalizedApplicantRows(
        ensureSubmissionOwner(snapshot, row.agent_id),
        applicants,
      ),
      questionnaireAnswers,
    ),
    {
      exportedAt: row.exported_at,
      statusFallback: rowStatus,
    },
  );

  if (rowStatus !== "exported") {
    return attachExportPackageRow(normalizedSnapshot, rowStatus, exportBatches, {
      restoreGeneratedState: true,
    });
  }
  if (
    normalizedSnapshot.status === "exported" &&
    normalizedSnapshot.exportState === "marked_exported"
  ) {
    return attachExportPackageRow(normalizedSnapshot, rowStatus, exportBatches, {
      restoreGeneratedState: true,
    });
  }

  const syncedAt = row.exported_at ?? row.updated_at;
  const historyId = `и-${normalizedSnapshot.id}-sync-exported`;
  const syncedHistory = normalizedSnapshot.history.some((item) => item.id === historyId)
    ? normalizedSnapshot.history
    : [
        {
          id: historyId,
          text: "Подача синхронизирована с завершенной выгрузкой",
          at: syncedAt,
          source: "system" as const,
        },
        ...normalizedSnapshot.history,
      ];

  return attachExportPackageRow(
    {
      ...normalizedSnapshot,
      status: "exported",
      exportState: "marked_exported",
      updatedAt: syncedAt,
      history: syncedHistory,
    },
    rowStatus,
    exportBatches,
    { restoreGeneratedState: true },
  );
}

function cockpitSnapshotFamilyIntelligence(submission: Submission): Json {
  // The normalized tables are a query projection; this snapshot owns the full cockpit UI model.
  return {
    status: cockpitSnapshotStatus,
    [cockpitSnapshotKey]: {
      version: cockpitSnapshotVersion,
      submission: submission as unknown as Json,
    },
  };
}

function stableUuid(seed: string): string {
  let hashA = 0x811c9dc5;
  let hashB = 0x01000193;

  for (const char of seed) {
    const code = char.codePointAt(0) ?? 0;
    hashA ^= code;
    hashA = Math.imul(hashA, 0x01000193);
    hashB ^= code + hashA;
    hashB = Math.imul(hashB, 0x85ebca6b);
  }

  const hex = [hashA, hashB, hashA ^ hashB, hashA + hashB]
    .map((value) => (value >>> 0).toString(16).padStart(8, "0"))
    .join("");

  return `${hex.slice(0, 8)}-${hex.slice(8, 12)}-4${hex.slice(13, 16)}-8${hex.slice(17, 20)}-${hex.slice(20, 32)}`;
}

function timestampOrNow(value: string | undefined): string {
  if (value && /^\d{4}-\d{2}-\d{2}(T.+)?$/.test(value)) {
    const parsed = new Date(value);
    if (!Number.isNaN(parsed.getTime())) return parsed.toISOString();
  }

  return new Date().toISOString();
}

function tripDate(submission: Submission): string {
  if (submission.tripDateFrom === submission.tripDateTo) return submission.tripDateFrom;
  return `${submission.tripDateFrom} - ${submission.tripDateTo}`;
}

function splitLegacyTripDateRange(value: string) {
  const normalized = value.trim();
  const rangeMatch = normalized.match(/^(.+?)\s+-\s+(.+)$/);
  if (!rangeMatch) return { from: normalized, to: normalized };

  const from = rangeMatch[1]?.trim() ?? normalized;
  const to = rangeMatch[2]?.trim() ?? normalized;
  return { from: from || normalized, to: to || normalized };
}

function tripDateRangeFromRow(
  row: Pick<SubmissionRow, "travel_date" | "trip_date_from" | "trip_date_to">,
) {
  const legacy = row.travel_date.trim();
  const legacyRange = splitLegacyTripDateRange(legacy);
  return {
    from: row.trip_date_from?.trim() || legacyRange.from,
    to: row.trip_date_to?.trim() || legacyRange.to,
  };
}

function toSupabaseStatus(status: SubmissionStatus): SupabaseSubmissionStatus {
  if (status === "requires_action") {
    throw new Error("Legacy status cannot be written by canonical submissions flow.");
  }

  switch (status) {
    case "draft":
      return "draft";
    case "in_progress":
      return "filling";
    case "submitted_for_review":
      return "waiting_review";
    case "returned":
      return "returned";
    case "corrections_received":
      return "waiting_review";
    case "ready_for_export":
      return "ready_for_excel";
    case "exported":
      return "exported";
  }
}

function fromSupabaseSubmissionRowStatus(
  row: Pick<SubmissionRow, "exported_at" | "status">,
): SubmissionStatus {
  const normalized = normalizeLegacySubmissionStatus(row.status, {
    exportedAt: row.exported_at,
  });
  if (!normalized.ok) throw new Error(normalized.reason);
  return normalized.data;
}

function appointmentStatusForSubmission(submission: Submission): AppointmentStatus {
  return submission.status === "exported" ? "completed" : "not_started";
}

function issueStatusToCorrectionStatus(
  status: IssueStatus,
): CorrectionInsert["status"] {
  if (status === "closed_by_admin") return "closed";
  if (status === "fixed_by_agent") return "fixed";
  return "open";
}

function mediaTypeForIssue(type: SubmissionFileType | undefined) {
  if (!type) return null;
  const mediaType = toCanonicalStorageMediaType(type);
  return mediaType.ok ? mediaType.data : null;
}

function mediaTypeForFile(type: SubmissionFileType): MediaAssetInsert["type"] | null {
  const mediaType = toCanonicalStorageMediaType(type);
  return mediaType.ok ? mediaType.data : null;
}

function applicantRoleLabel(role: Applicant["role"]): string {
  if (role === "main") return "Основной заявитель";
  if (role === "spouse") return "Супруг";
  if (role === "child") return "Ребёнок";
  return "Заявитель";
}

function toApplicantInsert(
  submission: Submission,
  applicant: Applicant,
): ApplicantInsert {
  return {
    id: applicant.id,
    submission_id: submission.id,
    full_name: applicant.fullName,
    role: applicantRoleLabel(applicant.role),
    suggested_role: null,
    role_confirmed: true,
    birth_date: null,
    patronymic: null,
    citizenship: null,
    address: null,
    phone: null,
    email: null,
    passport_number: "",
    passport_issued_at: null,
    passport_expires_at: null,
    country: submission.country,
    city: submission.city,
    trip_dates: tripDate(submission),
    hotel_name: null,
    hotel_address: null,
    questionnaire_percent: submission.completeness.questionnaire,
    media_percent: submission.completeness.files,
  };
}

function toCorrectionInsert(
  submission: Submission,
  issue: Issue,
  actorId: string,
): CorrectionInsert {
  return {
    id: stableUuid(`correction:${submission.id}:${issue.id}`),
    submission_id: submission.id,
    applicant_id: issue.target.applicantId,
    scope: issue.type === "file" || issue.type === "media" ? "media" : "field",
    field_key: issue.target.field ?? null,
    media_type: mediaTypeForIssue(issue.target.fileType),
    reason: `${issue.reason}${issue.comment ? ` — ${issue.comment}` : ""}`,
    severity: issue.severity === "blocker" ? "blocking" : "note",
    status: issueStatusToCorrectionStatus(issue.status),
    created_by: actorId,
    created_at: timestampOrNow(issue.createdAt),
    fixed_at:
      issue.status === "fixed_by_agent" || issue.status === "closed_by_admin"
        ? new Date().toISOString()
        : null,
  };
}

function toStatusHistoryInsert(
  submission: Submission,
  item: PersistableStatusHistoryItem,
  actorId: string,
): StatusHistoryInsert {
  return {
    id: stableUuid(`history:${submission.id}:${item.id}`),
    entity_type: "submission",
    entity_id: submission.id,
    from_status: item.fromStatus,
    to_status: item.toStatus,
    comment: item.detail ? `${item.text} — ${item.detail}` : item.text,
    changed_by: actorId,
    changed_at: timestampOrNow(item.at),
  };
}

type PersistableStatusHistoryItem = Submission["history"][number] & {
  fromStatus: SubmissionStatus;
  toStatus: SubmissionStatus;
};

function isPersistableStatusHistoryItem(
  item: Submission["history"][number],
): item is PersistableStatusHistoryItem {
  return Boolean(item.fromStatus && item.toStatus);
}

function reviewStatusForFile(file: SubmissionFile): MediaAssetInsert["review_status"] {
  if (file.status === "accepted") return "accepted";
  if (file.status === "needs_replacement") {
    return file.reviewStatus === "poor_quality" ? "poor_quality" : "replace_required";
  }
  return file.reviewStatus ?? "not_reviewed";
}

function toCockpitMediaAssetInserts(submission: Submission): MediaAssetInsert[] {
  return submission.files.flatMap((file) => {
    if (!isPersistablePrivateFileAsset(file)) return [];

    const mediaType = mediaTypeForFile(file.type);
    if (!mediaType) return [];

    return [
      {
        id: stableUuid(`media:${submission.id}:${file.applicantId}:${file.type}`),
        applicant_id: file.applicantId,
        submission_id: submission.id,
        type: mediaType,
        original_file_name: file.originalFileName ?? null,
        generated_file_name: file.generatedFileName,
        storage_bucket: file.storageBucket,
        storage_path: file.storagePath,
        mime_type: file.mimeType ?? null,
        size_bytes: file.sizeBytes ?? null,
        upload_status: "uploaded",
        review_status: reviewStatusForFile(file),
        uploaded_at: timestampOrNow(file.uploadedAtIso ?? file.uploadedAt),
        reviewed_at: file.reviewedAtIso ? timestampOrNow(file.reviewedAtIso) : null,
        reviewed_by: file.reviewedBy ?? null,
      },
    ];
  });
}

export function toCockpitQuestionnaireAnswerInserts(
  submission: Submission,
  actorId: string,
): QuestionnaireAnswerInsert[] {
  return submission.applicants.flatMap((applicant) =>
    applicant.sections.flatMap((section) =>
      section.fields.map((field) => ({
        submission_id: submission.id,
        applicant_id: applicant.id,
        section_id: section.id,
        field_id: field.id,
        label: field.label,
        value: questionnaireAnswerJsonForField(field),
        updated_by: actorId,
      })),
    ),
  );
}

export function toCockpitDraftPersistencePayload(
  submission: Submission,
  actorId: string,
  ownerId: string,
  actorHistorySource: Extract<SubmissionHistorySource, "agent" | "admin"> =
    actorId === ownerId ? "agent" : "admin",
): SubmissionDraftPersistencePayload {
  const ownedSubmission = assignSubmissionOwner(
    ensureSubmissionOwner(submission, ownerId),
    ownerId,
  );

  return {
    submission: {
      id: ownedSubmission.id,
      agent_id: ownerId,
      type: ownedSubmission.type,
      title: ownedSubmission.title,
      country: ownedSubmission.country,
      city: ownedSubmission.city,
      travel_date: tripDate(ownedSubmission),
      trip_date_from: ownedSubmission.tripDateFrom,
      trip_date_to: ownedSubmission.tripDateTo,
      status: toSupabaseStatus(ownedSubmission.status),
      priority:
        ownedSubmission.status === "returned" ||
        ownedSubmission.status === "requires_action"
          ? "Высокий"
          : "Средний",
      readiness_percent: ownedSubmission.completeness.total,
      family_intelligence: cockpitSnapshotFamilyIntelligence(ownedSubmission),
      appointment_status: appointmentStatusForSubmission(ownedSubmission),
      submitted_at:
        ownedSubmission.status === "submitted_for_review"
          ? timestampOrNow(ownedSubmission.updatedAt)
          : null,
      review_started_at: null,
      accepted_at:
        ownedSubmission.status === "ready_for_export" ||
        ownedSubmission.status === "exported"
          ? timestampOrNow(ownedSubmission.updatedAt)
          : null,
      exported_at:
        ownedSubmission.status === "exported"
          ? timestampOrNow(ownedSubmission.updatedAt)
          : null,
      updated_at: timestampOrNow(ownedSubmission.updatedAt),
    },
    applicants: ownedSubmission.applicants.map((applicant) =>
      toApplicantInsert(ownedSubmission, applicant),
    ),
    questionnaire_answers: toCockpitQuestionnaireAnswerInserts(
      ownedSubmission,
      actorId,
    ),
    media_assets: toCockpitMediaAssetInserts(ownedSubmission),
    corrections: ownedSubmission.issues.map((issue) =>
      toCorrectionInsert(ownedSubmission, issue, actorId),
    ),
    status_history: ownedSubmission.history
      .filter(isPersistableStatusHistoryItem)
      .filter((item) => item.source === actorHistorySource)
      .map((item) => toStatusHistoryInsert(ownedSubmission, item, actorId)),
  };
}

function requiresCorrectionHandoff(submission: Submission): boolean {
  return (
    submission.status === "corrections_received" &&
    submission.issues.some((issue) => issue.status === "fixed_by_agent")
  );
}

export function reviewHandoffPersistenceIssues(
  submission: Submission,
  role?: Role,
): string[] {
  const openIssues = submission.issues.filter((issue) => issue.status === "open");
  const fixedIssues = submission.issues.filter(
    (issue) => issue.status === "fixed_by_agent",
  );
  const unresolvedIssues = [...openIssues, ...fixedIssues];
  const issues: string[] = [];

  if (submission.status === "submitted_for_review") {
    if (unresolvedIssues.length > 0) {
      issues.push("submitted_for_review cannot carry unresolved issues");
    }
    const mediaReadiness = canonicalRequiredMediaReadiness(submission, {
      requireStorageIdentity: true,
    });
    if (!mediaReadiness.ok) {
      issues.push(
        `submitted_for_review requires canonical media: ${mediaReadiness.reason}`,
      );
    }
    if (!hasHandoffHistory(submission, "submitted_for_review", "agent", role)) {
      issues.push("submitted_for_review requires matching agent history");
    }
  }

  if (submission.status === "returned") {
    if (openIssues.length === 0) {
      issues.push("returned requires at least one open issue");
    }
    if (!hasHandoffHistory(submission, "returned", "admin", role)) {
      issues.push("returned requires matching admin history");
    }
  }

  if (submission.status === "corrections_received") {
    const unresolvedFixedTargets = fixedIssues.filter(
      (issue) => !isSubmissionIssueResolved(submission, issue),
    );
    if (openIssues.length > 0) {
      issues.push("corrections_received cannot persist open issues");
    }
    if (fixedIssues.length === 0) {
      issues.push("corrections_received requires fixed_by_agent issues");
    }
    if (unresolvedFixedTargets.length > 0) {
      issues.push("corrections_received fixed issues must resolve their targets");
    }
    if (!hasHandoffHistory(submission, "corrections_received", "agent", role)) {
      issues.push("corrections_received requires matching agent history");
    }
  }

  if (submission.status === "ready_for_export") {
    if (unresolvedIssues.length > 0) {
      issues.push("ready_for_export cannot persist unresolved issues");
    }
    const mediaReadiness = canonicalRequiredMediaReadiness(submission, {
      requireAccepted: true,
      requireStorageIdentity: true,
    });
    if (!mediaReadiness.ok) {
      issues.push(
        `ready_for_export requires accepted canonical media: ${mediaReadiness.reason}`,
      );
    }
    if (!hasHandoffHistory(submission, "ready_for_export", "admin", role)) {
      issues.push("ready_for_export requires matching admin history");
    }
  }

  return issues;
}

function assertReviewHandoffPersistenceConsistency(
  submission: Submission,
  role: Role,
): void {
  if (!isReviewHandoffCommandWrite(submission, role)) return;

  const issues = reviewHandoffPersistenceIssues(submission, role);
  if (issues.length === 0) return;
  const operation = requiresCorrectionHandoff(submission)
    ? "rpc.submit_corrections_handoff"
    : "rpc.save_submission_draft";

  throw new PersistenceObservableError(
    `${operation} failed safely (${operation}:save:HANDOFF_CONSISTENCY).`,
    {
      operation,
      kind: "save",
      safeCode: `${operation}:save:HANDOFF_CONSISTENCY`,
      retryable: false,
    },
    {
      cause: new Error(issues.join("; ")),
    },
  );
}

function hasHandoffHistory(
  submission: Submission,
  toStatus: SubmissionStatus,
  source: NonNullable<Submission["history"][number]["source"]>,
  role?: Role,
): boolean {
  const allowedFromStatuses = handoffAllowedFromStatuses[toStatus] ?? [];
  const hasTypedHistory = submission.history.some(
    (item) => item.fromStatus || item.toStatus,
  );
  const hasExactTypedHistory = submission.history.some(
    (item) =>
      item.toStatus === toStatus &&
      item.source === source &&
      Boolean(item.fromStatus) &&
      allowedFromStatuses.includes(item.fromStatus as SubmissionStatus),
  );
  if (hasExactTypedHistory) return true;
  if (hasTypedHistory || (role && isCurrentLocalHandoffWrite(submission, role))) {
    return false;
  }

  return submission.history.some((item) => {
    if (item.source !== source) return false;

    const text = item.text.toLowerCase();
    if (toStatus === "submitted_for_review") {
      return text.includes("провер");
    }
    if (toStatus === "returned") {
      return text.includes("вернул") || text.includes("возврат");
    }
    if (toStatus === "corrections_received") {
      return text.includes("исправ");
    }
    if (toStatus === "ready_for_export") {
      return text.includes("прин") || text.includes("готов");
    }

    return false;
  });
}

const handoffAllowedFromStatuses: Partial<
  Record<SubmissionStatus, SubmissionStatus[]>
> = {
  submitted_for_review: transitionMatrix.submit_for_review.from,
  returned: [
    ...transitionMatrix.return_with_issues.from,
    ...transitionMatrix.return_again.from,
  ],
  corrections_received: transitionMatrix.submit_corrections.from,
  ready_for_export: [
    ...transitionMatrix.accept.from,
    ...transitionMatrix.close_issues_accept.from,
  ],
};

function isCurrentLocalHandoffWrite(submission: Submission, role: Role): boolean {
  if (submission.updatedAt !== "сейчас") return false;

  if (submission.status === "submitted_for_review") {
    return role === "agent";
  }
  if (submission.status === "returned") {
    return role === "admin" && submission.issues.some(
      (issue) =>
        issue.status === "open" &&
        issue.createdAt === "сейчас" &&
        issue.createdBy === "admin",
    );
  }
  if (submission.status === "corrections_received") {
    return role === "agent";
  }
  if (submission.status === "ready_for_export") {
    return role === "admin" && submission.exportState === "ready";
  }

  return false;
}

function isReviewHandoffCommandWrite(submission: Submission, role: Role): boolean {
  if (!handoffAllowedFromStatuses[submission.status]) return false;
  if (submission.history[0]?.toStatus === submission.status) {
    return true;
  }

  return isCurrentLocalHandoffWrite(submission, role);
}

function fallbackSubmissionFromRows(
  row: SubmissionRow,
  applicants: CockpitApplicantRow[],
  questionnaireAnswers: CockpitQuestionnaireAnswerRow[],
): Submission {
  const tripDateRange = tripDateRangeFromRow(row);
  const applicantItems: Applicant[] = applicants.map((applicant) => ({
    id: applicant.id,
    fullName: applicant.full_name,
    role: "main",
    questionnaireStatus:
      applicant.questionnaire_percent >= 100 ? "complete" : "partial",
    fileStatus: applicant.media_percent >= 100 ? "complete" : "partial",
    sections: questionnaireSectionsFromAnswerRows(
      applicant.id,
      questionnaireAnswers.filter((answer) => answer.applicant_id === applicant.id),
    ),
  }));

  return normalizeSubmissionQuestionnaire({
    id: row.id,
    agentId: row.agent_id,
    title: row.title,
    listTitle:
      row.type === "family"
        ? familyListTitleFromMainApplicantName(applicantItems[0]?.fullName)
        : undefined,
    type: row.type,
    country: "Испания",
    city:
      row.city === "Москва" || row.city === "Санкт-Петербург" || row.city === "Казань"
        ? row.city
        : "Москва",
    tripDateFrom: tripDateRange.from,
    tripDateTo: tripDateRange.to,
    status: fromSupabaseSubmissionRowStatus(row),
    applicants: applicantItems,
    issues: [],
    files: [],
    completeness: {
      questionnaire: row.readiness_percent,
      files: 0,
      total: row.readiness_percent,
    },
    exportState: row.status === "exported" ? "marked_exported" : "not_ready",
    createdAt: row.created_at,
    updatedAt: row.updated_at,
    history: [],
  });
}

function questionnaireSectionsFromAnswerRows(
  applicantId: string,
  answers: CockpitQuestionnaireAnswerRow[],
) {
  const sectionsById = new Map<string, CockpitQuestionnaireAnswerRow[]>();
  for (const answer of answers) {
    const current = sectionsById.get(answer.section_id) ?? [];
    current.push(answer);
    sectionsById.set(answer.section_id, current);
  }

  return Array.from(sectionsById.entries()).map(([sectionId, sectionAnswers]) => ({
    id: sectionId,
    title: sectionId,
    status: "partial" as const,
    fields: sectionAnswers.map((answer) => {
      const value = questionnaireAnswerFieldValue(answer.value);

      return {
        id: answer.field_id,
        label: answer.label,
        required: true,
        reviewConfirmedAtIso: value.reviewConfirmedAtIso,
        reviewConfirmedBy: value.reviewConfirmedBy,
        reviewOriginSource: value.reviewOriginSource,
        reviewSource: value.reviewSource,
        reviewState: value.reviewState,
        value: value.value,
      };
    }),
  }));
}

function questionnaireAnswerJsonForField(field: QuestionnaireField): Json {
  if (
    !field.reviewState &&
    !field.reviewSource &&
    !field.reviewOriginSource &&
    !field.reviewConfirmedAtIso &&
    !field.reviewConfirmedBy
  ) {
    return field.value;
  }

  const envelope: QuestionnaireAnswerValueEnvelope = {
    kind: questionnaireAnswerEnvelopeKind,
    value: field.value,
    version: questionnaireAnswerEnvelopeVersion,
  };

  if (field.reviewConfirmedAtIso) {
    envelope.reviewConfirmedAtIso = field.reviewConfirmedAtIso;
  }

  if (field.reviewConfirmedBy) {
    envelope.reviewConfirmedBy = field.reviewConfirmedBy;
  }

  if (field.reviewOriginSource) {
    envelope.reviewOriginSource = field.reviewOriginSource;
  }

  if (field.reviewState) {
    envelope.reviewState = field.reviewState;
  }

  if (field.reviewSource) {
    envelope.reviewSource = field.reviewSource;
  }

  return envelope;
}

function questionnaireAnswerFieldValue(value: Json): QuestionnaireAnswerValueResult {
  if (isRecord(value) && value.kind === questionnaireAnswerEnvelopeKind) {
    if (
      value.version !== undefined &&
      value.version !== questionnaireAnswerEnvelopeVersion
    ) {
      return { value: typeof value.value === "string" ? value.value : "" };
    }

    return {
      reviewConfirmedAtIso:
        typeof value.reviewConfirmedAtIso === "string"
          ? value.reviewConfirmedAtIso
          : undefined,
      reviewConfirmedBy:
        typeof value.reviewConfirmedBy === "string"
          ? value.reviewConfirmedBy
          : undefined,
      reviewOriginSource: isQuestionnaireReviewSource(value.reviewOriginSource)
        ? value.reviewOriginSource
        : undefined,
      reviewSource: isQuestionnaireReviewSource(value.reviewSource)
        ? value.reviewSource
        : undefined,
      reviewState: isQuestionnaireReviewState(value.reviewState)
        ? value.reviewState
        : undefined,
      value: typeof value.value === "string" ? value.value : "",
    };
  }

  if (typeof value === "string") return { value };
  if (value === null) return { value: "" };
  return { value: JSON.stringify(value) };
}

export async function loadCockpitSubmissionsForProfile(
  profile: AppProfile,
): Promise<CockpitLoadResult> {
  const client = getSupabaseClient();
  if (!client) {
    return {
      ownerIdsBySubmissionId: new Map(),
      submissions: [],
    };
  }

  const query = client
    .from("submissions")
    .select(submissionSelect)
    .order("updated_at", { ascending: false })
    .limit(submissionListLimit);
  const { data: rows, error } =
    profile.role === "agent" ? await query.eq("agent_id", profile.id) : await query;

  if (error) {
    throw mapSupabasePersistenceError(error, {
      operation: "submissions.list",
      fallbackKind: "database",
    });
  }

  if (!rows?.length) {
    return {
      ownerIdsBySubmissionId: new Map(),
      submissions: [],
    };
  }

  const submissionIds = rows.map((row) => row.id);
  const { data: applicantRows, error: applicantError } = await client
    .from("applicants")
    .select(applicantSelect)
    .in("submission_id", submissionIds);

  if (applicantError) {
    throw mapSupabasePersistenceError(applicantError, {
      operation: "applicants.list",
      fallbackKind: "database",
    });
  }

  const { data: questionnaireRows, error: questionnaireError } = await client
    .from("questionnaire_answers")
    .select(questionnaireAnswerSelect)
    .in("submission_id", submissionIds);

  if (questionnaireError) {
    throw mapSupabasePersistenceError(questionnaireError, {
      operation: "questionnaire_answers.list",
      fallbackKind: "database",
    });
  }

  const { data: mediaRows, error: mediaError } = await client
    .from("media_assets")
    .select(mediaAssetSelect)
    .in("submission_id", submissionIds);

  if (mediaError) {
    throw mapSupabasePersistenceError(mediaError, {
      operation: "media_assets.list",
      fallbackKind: "database",
    });
  }

  const exportBatchRows =
    profile.role === "admin"
      ? await loadExportBatchRowsForSubmissions(submissionIds)
      : [];

  const ownerIdsBySubmissionId = new Map<string, string>();
  const submissions = rows.map((row) => {
    ownerIdsBySubmissionId.set(row.id, row.agent_id);
    const submissionApplicants = (applicantRows ?? []).filter(
      (applicant) => applicant.submission_id === row.id,
    );
    const submissionQuestionnaireAnswers = (questionnaireRows ?? []).filter(
      (answer) => answer.submission_id === row.id,
    );
    const submissionExportBatches = exportBatchRows.filter((batch) =>
      batch.submission_ids.includes(row.id),
    );
    const submissionMediaRows = (mediaRows ?? []).filter(
      (media) => media.submission_id === row.id,
    );
    const snapshot = readCockpitSnapshot(row.family_intelligence);
    if (snapshot) {
      return attachDurableMediaAssetRows(
        reconcileCockpitSnapshotWithSubmissionRow(
          row,
          snapshot,
          submissionApplicants,
          submissionQuestionnaireAnswers,
          submissionExportBatches,
        ),
        submissionMediaRows,
      );
    }

    return attachDurableMediaAssetRows(
      attachExportPackageRow(
        fallbackSubmissionFromRows(
          row,
          submissionApplicants,
          submissionQuestionnaireAnswers,
        ),
        fromSupabaseSubmissionRowStatus(row),
        submissionExportBatches,
      ),
      submissionMediaRows,
    );
  });

  return {
    ownerIdsBySubmissionId,
    submissions,
  };
}

async function loadExportBatchRowsForSubmissions(
  submissionIds: string[],
): Promise<CockpitExportBatchRow[]> {
  if (!submissionIds.length) return [];

  const client = getSupabaseClient();
  if (!client) return [];

  const { data, error } = await client
    .from("export_batches")
    .select(exportBatchSelect)
    .overlaps("submission_ids", submissionIds);

  if (error) {
    throw mapSupabasePersistenceError(error, {
      operation: "export_batches.list",
      fallbackKind: "database",
    });
  }

  return data ?? [];
}

export async function saveCockpitSubmissionsForProfile(
  profile: AppProfile,
  submissions: Submission[],
  ownerIdsBySubmissionId: ReadonlyMap<string, string>,
): Promise<Map<string, string>> {
  const client = getSupabaseClient();
  if (!client) return new Map(ownerIdsBySubmissionId);

  const nextOwnerIds = new Map(ownerIdsBySubmissionId);

  for (const submission of submissions) {
    assertReviewHandoffPersistenceConsistency(submission, profile.role);

    const ownerId =
      profile.role === "admin"
        ? (nextOwnerIds.get(submission.id) ?? submission.agentId ?? profile.id)
        : profile.id;
    const payload = toCockpitDraftPersistencePayload(
      submission,
      profile.id,
      ownerId,
      profile.role,
    );
    const { error } = requiresCorrectionHandoff(submission)
      ? await client.rpc("submit_corrections_handoff", { payload })
      : await client.rpc("save_submission_draft", { payload });

    if (error) {
      throw mapSupabasePersistenceError(error, {
        operation: requiresCorrectionHandoff(submission)
          ? "rpc.submit_corrections_handoff"
          : "rpc.save_submission_draft",
        fallbackKind: "save",
      });
    }

    nextOwnerIds.set(submission.id, ownerId);
  }

  return nextOwnerIds;
}
