VisaFlow export package
Submissions: 3
Applicants: 6
Document files: 24
Workbook: visaflow-export-01j4aqx.xlsx
Required files per applicant: passport_scan, selfie_1, selfie_2
Archive structure: VisaFlow_Export_YYYY-MM-DD / city / family-or-applicant / documents.