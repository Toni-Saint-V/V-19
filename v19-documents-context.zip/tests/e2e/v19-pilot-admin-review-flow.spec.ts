import { expect, test, type Page } from "@playwright/test";
import {
  clearExportSelection,
  clickWorkspaceButton,
  collectBrowserProblems,
  drawer,
  expectDrawerStatus,
  isVisible,
  openDrawerTab,
  openFreshWorkspace,
  submissionCard,
} from "./v19-pilot-helpers";

async function openAdminSubmission(
  page: Page,
  cardText: string,
  drawerTitle = cardText,
) {
  const targetCard = submissionCard(page, cardText);
  await expect(targetCard).toBeVisible();
  await targetCard.click();
  if (!(await isVisible(drawer(page)))) {
    const explicitOpenAction = targetCard
      .locator(".v17-admin-row-action, .v19-admin-row-action")
      .first();

    if (await isVisible(explicitOpenAction)) {
      await explicitOpenAction.click();
    } else {
      await targetCard.click();
    }
  }
  await expect(drawer(page)).toBeVisible();
  await expect(
    drawer(page)
      .getByRole("heading", { name: drawerTitle })
      .or(drawer(page).getByText(drawerTitle).first())
      .first(),
  ).toBeVisible();
}

test.describe("V-19 pilot admin review click flow", () => {
  test("admin queue opens drawer tabs and returns a precise field issue", async ({
    page,
  }, testInfo) => {
    test.skip(testInfo.project.name !== "chromium", "desktop pilot runs once");
    const browserProblems = collectBrowserProblems(page);

    await openFreshWorkspace(page, {
      heading: "Проверка",
      workspaceEmail: "admin@visaflow.local",
    });
    await expect(page.getByText("Локальный демо-режим").first()).toBeVisible();
    await expect(page.locator(".ops-nav").getByRole("button", { name: "Входящие" })).toHaveCount(0);
    await expect(page.locator(".ops-nav").getByRole("button", { name: "Мои действия" })).toHaveCount(0);
    await expect(page.locator(".ops-nav").getByRole("button", { name: "Мои подачи" })).toHaveCount(0);

    await clickWorkspaceButton(page, /Проверка|Работа/);
    await expect(submissionCard(page, "Нина Волкова")).toBeVisible();
    await openAdminSubmission(page, "Нина Волкова");

    await openDrawerTab(page, ["Обзор"]);
    await openDrawerTab(page, ["Анкета", "Данные"]);
    await openDrawerTab(page, ["Файлы"]);
    await openDrawerTab(page, ["Замечания"]);
    await expect(drawer(page).getByRole("tab", { name: "Паспорт" })).toHaveCount(0);
    await expect(drawer(page).getByRole("tab", { name: "Селфи" })).toHaveCount(0);

    await openDrawerTab(page, ["Замечания"]);
    await drawer(page).getByRole("button", { name: "Добавить замечание" }).click();
    const remarkDialog = page.getByRole("dialog", { name: "Новое замечание" });
    await expect(remarkDialog).toBeVisible();
    await remarkDialog.getByRole("button", { name: "Создать замечание" }).click();

    const issueSummary = drawer(page)
      .locator("article")
      .filter({ hasText: "Требуется уточнение" })
      .filter({ hasText: "Нина Волкова" })
      .filter({ hasText: "Анкета" })
      .first();
    await expect(issueSummary).toBeVisible();
    await drawer(page).getByRole("button", { exact: true, name: "Вернуть" }).click();
    await expectDrawerStatus(page, "Возвращено");

    expect(browserProblems, browserProblems.join("\n")).toEqual([]);
  });

  test("admin closes corrections and downloads ZIP export package", async ({
    page,
  }, testInfo) => {
    test.skip(testInfo.project.name !== "chromium", "desktop pilot runs once");
    const browserProblems = collectBrowserProblems(page);

    await openFreshWorkspace(page, {
      heading: "Проверка",
      workspaceEmail: "admin@visaflow.local",
    });
    await expect(page.getByText("Локальный демо-режим").first()).toBeVisible();
    await page.getByRole("tab", { name: /Исправления/ }).click();
    await openAdminSubmission(page, "Петровы", "Семья Петровых");
    await expect(drawer(page).getByText("Исправления получены").first()).toBeVisible();
    await expect(drawer(page).getByText(/1 исправлено|Исправлено 1/).first()).toBeVisible();
    await drawer(page).getByRole("button", { name: "Закрыть и принять" }).click();
    await expectDrawerStatus(page, "Готово к выгрузке");
    await drawer(page)
      .getByRole("button", { name: /Закрыть (подачу|проверку)/ })
      .click();

    await clickWorkspaceButton(page, /Выгрузка/);
    await expect(
      page.getByRole("heading", { level: 1, name: "Выгрузка" }),
    ).toBeVisible();
    await clearExportSelection(page);
    await page
      .locator(".export-row")
      .filter({ hasText: "Семья Петровых" })
      .getByRole("checkbox")
      .check();
    await expect(
      page.getByRole("heading", { name: "1 подача · 2 заявителя" }),
    ).toBeVisible();
    await expect(page.getByText("Sheet1 · предпросмотр")).toBeVisible();
    await expect(page.getByRole("button", { name: "Скачать ZIP + Excel" })).toBeDisabled();

    await page.getByRole("button", { name: "Сформировать Excel" }).click();
    await expect(page.getByRole("button", { name: "Скачать ZIP + Excel" })).toBeEnabled();
    const downloadPromise = page.waitForEvent("download");
    await page.getByRole("button", { name: "Скачать ZIP + Excel" }).click();
    const download = await downloadPromise;
    expect(download.suggestedFilename()).toMatch(/^visaflow-export-.+_documents\.zip$/);
    await expect(download.failure()).resolves.toBeNull();

    expect(browserProblems, browserProblems.join("\n")).toEqual([]);
  });
});
