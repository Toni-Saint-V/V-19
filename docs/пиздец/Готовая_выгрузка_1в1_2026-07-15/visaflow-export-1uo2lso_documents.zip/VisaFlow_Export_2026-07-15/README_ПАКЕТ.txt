VisaFlow export package
Submissions: 2
Applicants: 5
Document files: 20
Workbook: visaflow-export-1uo2lso.xlsx
Required files per applicant: passport_scan, selfie_1, selfie_2
Archive structure: VisaFlow_Export_YYYY-MM-DD / city / family-or-applicant / documents.